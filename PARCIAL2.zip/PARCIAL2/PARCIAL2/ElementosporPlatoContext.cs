﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PARCIAL2.Models;

namespace PARCIAL2
{
    public class ElementosporPlatoContext : DbContext
    {
        public ElementosporPlatoContext(DbContextOptions<ElementosporPlatoContext> options) : base(options)
        {
         
        }

        public DbSet<CompraElementos>  CompraElementos { get; set; }
        public DbSet<Empresas> Empresas { get; set; }
        public DbSet<Platos> Platos { get; set; }
        public DbSet<Elementos> Elementos { get; set; }
        public DbSet<PlatosporCombo> PlatosporCombos { get; set; }
        public DbSet<ElementosporPlato> ElementosporPlatos { get; set; }
    }
}
