﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace PARCIAL2.Models
{
    public class Platos
    {
        [Key]
        public char PlatoID { get; set; }
        public char EmpresaID { get; set; }
        public char GrupoID { get; set; }
        public string NombrePlato { get; set; }
        public string DescripcionPlato { get; set; }
        public decimal Precio { get; set; }
        public TimeSpan TiempoPreparacion { get; set; }
        public byte Imagen { get; set; }
        public decimal AplicaPropina { get; set; }
        public char Lunes { get; set; }
        public char Martes { get; set; }
        public char Miercoles { get; set; }
        public char Jueves { get; set; }
        public char Viernes { get; set; }
        public char Sabado { get; set; }
        public char Domingo { get; set; }
        public char Estado { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime FechaModificacion { get; set; }
    }
}
