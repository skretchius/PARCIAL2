﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace PARCIAL2.Models
{
    public class PlatosporCombo
    {

        [Key]
        public char PlatosPorComboID { get; set; }
        public char EmpresaID { get; set; }
        public char ComboID { get; set; }
        public char PlatoID { get; set; }
        public string Estado { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime FechaModificacion { get; set; }
    }
}
