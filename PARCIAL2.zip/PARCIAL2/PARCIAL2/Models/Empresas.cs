﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace PARCIAL2.Models
{
    public class Empresas
    {
        [Key]
        public char EmpresaID { get; set; }
        public string NombreEmpresa { get; set; }
        public string Representante { get; set; }
        public char NIT { get; set; }
        public char NRC { get; set; }
        public string Direccion { get; set; }
        public string Correo { get; set; }
        public string Estado { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime FechaModificacion { get; set; }
    }
}
