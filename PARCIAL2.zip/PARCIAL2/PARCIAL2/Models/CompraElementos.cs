﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace PARCIAL2.Models
{
    public class CompraElementos
    {
        [Key]
        public char CompraID { get; set; }
        public char EmpresaID { get; set; }
        public DateTime FechaCompra { get; set; }
        public char ElementoID { get; set; }
        public int Cantidad { get; set; }
        public string Estado { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime FechaModificacion { get; set; }
    }
}
