using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PARCIAL2.Models;

namespace PARCIAL2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompraElementosController : ControllerBase
    {

        private readonly ElementosporPlatoContext _contexto;
        public CompraElementosController(ElementosporPlatoContext miContexto)
        {
            this._contexto = miContexto;
        }

        ///OBTERNER TODOS
        [HttpGet]
        [Route("api/ElementoPorPlato")]
        public IActionResult Get()
        {
            var CompraeList = from ce in _contexto.CompraElementos
                              join em in _contexto.Empresas on ce.EmpresaID equals em.EmpresaID
                              join el in _contexto.Elementos on ce.ElementoID equals el.ElementoID
                              select new {
                                  ce.CompraID,
                                  ce.EmpresaID,
                                 em.NombreEmpresa,
                                 ce.FechaCompra,
                                  ce.ElementoID,
                                 el.Elemento,
                                 ce.Cantidad,
                                 ce.Estado,
                                 ce.FechaCreacion,
                                  ce.FechaModificacion
                              };

                              
            if (CompraeList.Count() > 0)
            {
                return Ok(CompraeList);
            }
            return NotFound();
        }

        ///OBTERNER ID
        [HttpGet]
        [Route("api/ElementoPorPlato/{ID}")]
        public IActionResult GetByID(char ID) {
            var CE = from ce in _contexto.CompraElementos
                     join em in _contexto.Empresas on ce.EmpresaID equals em.EmpresaID
                     join el in _contexto.Elementos on ce.ElementoID equals el.ElementoID
                     where ce.CompraID == ID
                     select new {
                        ce.CompraID,
                         ce.EmpresaID,
                        em.NombreEmpresa,
                        ce.FechaCompra,
                        ce.ElementoID,
                        el.Elemento,
                        ce.Cantidad,
                        ce.Estado,
                        ce.FechaCreacion,
                         ce.FechaModificacion
                     };
            if(CE != null) {
                return Ok(CE);
            }
            return NotFound();
        }

        
        ///INGRESAR 
        [HttpPost]
        [Route("api/ElementoPorPlato")]
        public IActionResult guardarCompraElemento([FromBody] CompraElementos CENuevo)
        {
            try
            {
                var CEExist = from ce in _contexto.CompraElementos
                              join em in _contexto.Empresas on ce.EmpresaID equals em.EmpresaID
                              join el in _contexto.Elementos on ce.ElementoID equals el.ElementoID
                              where ce.CompraID == CENuevo.CompraID
                              select new {
                                 ce.CompraID,
                                  ce.EmpresaID,
                                 em.NombreEmpresa,
                                 ce.FechaCompra,
                                  ce.ElementoID,
                                 el.Elemento,
                                  ce.Cantidad,
                                 ce.Estado,
                                 ce.FechaCreacion,
                                 ce.FechaModificacion
                              };
                               
                if (CEExist.Count() == 0)
                {
                    _contexto.CompraElementos.Add(CENuevo);
                    _contexto.SaveChanges();
                    return Ok(CENuevo);
                }
                return Ok(CEExist);
            }
            catch (System.Exception)
            {
                return BadRequest();
            }
        }


        ///MODIFICAR
        [HttpPut]
        [Route("api/ElementoPorPlato")]
        public IActionResult updateElementoPorPlato([FromBody] CompraElementos CEMod)
        {
            var CEExist = (from ce in _contexto.CompraElementos
                           join em in _contexto.Empresas on ce.EmpresaID equals em.EmpresaID
                           join el in _contexto.Elementos on ce.ElementoID equals el.ElementoID
                           where ce.CompraID == CEMod.CompraID
                           select new {
                               ce.CompraID,
                              ce.EmpresaID,
                              em.NombreEmpresa,
                              ce.FechaCompra,
                               ce.ElementoID,
                              el.Elemento,
                              ce.Cantidad,
                              ce.Estado,
                              ce.FechaCreacion,
                               ce.FechaModificacion
                           }).FirstOrDefault();
            if (CEExist is null)
            {
                return NotFound();
            }

            CEExist.CompraID           = CEMod.CompraID;
            CEExist.EmpresaID          = CEMod.EmpresaID;
            CEExist.FechaCompra        = CEMod.FechaCompra;
            CEExist.ElementoID         = CEMod.ElementoID;
            CEExist.Cantidad           = CEMod.Cantidad;
            CEExist.Estado             = CEMod.Estado;
            CEExist.FechaCreacion      = CEMod.FechaCreacion;
            CEExist.FechaModificacion  = CEMod.FechaModificacion;

            _contexto.Entry(CEExist).State = EntityState.Modified;
            _contexto.SaveChanges();

            return Ok(CEExist);

        }
    }
}