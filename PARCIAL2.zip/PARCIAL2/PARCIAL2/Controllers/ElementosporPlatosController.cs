﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PARCIAL2.Models;

namespace PARCIAL2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ElementosporPlatosController : ControllerBase
    {

        private readonly ElementosporPlatoContext _contexto;
        public ElementosporPlatosController(ElementosporPlatoContext miContexto)
        {
            this._contexto = miContexto;
        }

        ///OBTERNER TODOS
        [HttpGet]
        [Route("api/ElementoPorPlato")]
        public IActionResult Get()
        {
            var ElementosppList = from ep in _contexto.ElementosporPlatos
                                  join em in _contexto.Empresas on ep.EmpresaID equals em.EmpresaID
                                  join pl in _contexto.Platos on ep.PlatoID equals pl.PlatoID
                                  join el in _contexto.Elementos on ep.ElementoID equals el.ElementoID
                                  select new
                                  {
                                      ep.ElementoPorPlatoID,
                                      ep.EmpresaID,
                                      em.NombreEmpresa,
                                      ep.PlatoID,
                                      pl.NombrePlato,
                                      ep.ElementoID,
                                      el.Elemento,
                                      ep.Cantidad,
                                      ep.Estado,
                                      ep.FechaCreacion,
                                      ep.FechaModificacion
                                  };


            if (ElementosppList.Count() > 0)
            {
                return Ok(ElementosppList);
            }
            return NotFound();
        }

        ///OBTERNER ID
        [HttpGet]
        [Route("api/ElementoPorPlato/{ID}")]
        public IActionResult GetByID(char ID)
        {
            var Elementopp = from ep in _contexto.ElementosporPlatos
                             join em in _contexto.Empresas on ep.EmpresaID equals em.EmpresaID
                             join pl in _contexto.Platos on ep.PlatoID equals pl.PlatoID
                             join el in _contexto.Elementos on ep.ElementoID equals el.ElementoID
                             where ep.ElementoPorPlatoID == ID
                             select new
                             {
                                 ep.ElementoPorPlatoID,
                                 ep.EmpresaID,
                                 em.NombreEmpresa,
                                 ep.PlatoID,
                                 pl.NombrePlato,
                                 ep.ElementoID,
                                 el.Elemento,
                                 ep.Cantidad,
                                 ep.Estado,
                                 ep.FechaCreacion,
                                 ep.FechaModificacion
                             };
            if (Elementopp != null)
            {
                return Ok(Elementopp);
            }
            return NotFound();
        }


        ///INGRESAR 
        [HttpPost]
        [Route("api/ElementoPorPlato")]
        public IActionResult guardarElementoPorPlato([FromBody] ElementosporPlato EPPNuevo)
        {
            try
            {
                var EPPExist = from ep in _contexto.ElementosporPlatos
                               join em in _contexto.Empresas on ep.EmpresaID equals em.EmpresaID
                               join pl in _contexto.Platos on ep.PlatoID equals pl.PlatoID
                               join el in _contexto.Elementos on ep.ElementoID equals el.ElementoID
                               where ep.ElementoPorPlatoID == EPPNuevo.ElementoPorPlatoID
                               select new
                               {
                                   ep.ElementoPorPlatoID,
                                   ep.EmpresaID,
                                   em.NombreEmpresa,
                                   ep.PlatoID,
                                   pl.NombrePlato,
                                   ep.ElementoID,
                                   el.Elemento,
                                   ep.Cantidad,
                                   ep.Estado,
                                   ep.FechaCreacion,
                                   ep.FechaModificacion
                               };

                if (EPPExist.Count() == 0)
                {
                    _contexto.ElementosporPlatos.Add(EPPNuevo);
                    _contexto.SaveChanges();
                    return Ok(EPPNuevo);
                }
                return Ok(EPPExist);
            }
            catch (System.Exception)
            {
                return BadRequest();
            }
        }


        ///MODIFICAR
        [HttpPut]
        [Route("api/ElementoPorPlato")]
        public IActionResult updateElementoPorPlato([FromBody] ElementosporPlato eppMod)
        {
            var eppExist = (from ep in _contexto.ElementosporPlatos
                            join em in _contexto.Empresas on ep.EmpresaID equals em.EmpresaID
                            join pl in _contexto.Platos on ep.PlatoID equals pl.PlatoID
                            join el in _contexto.Elementos on ep.ElementoID equals el.ElementoID
                            where ep.ElementoPorPlatoID == eppMod.ElementoPorPlatoID
                            select new
                            {
                                ep.ElementoPorPlatoID,
                                ep.EmpresaID,
                                em.NombreEmpresa,
                                ep.PlatoID,
                                pl.NombrePlato,
                                ep.ElementoID,
                                el.Elemento,
                                ep.Cantidad,
                                ep.Estado,
                                ep.FechaCreacion,
                                ep.FechaModificacion
                            }).FirstOrDefault();
            if (eppExist is null)
            {
                return NotFound();
            }

            eppExist.ElementoPorPlatoID = eppMod.ElementoPorPlatoID;
            eppExist.EmpresaID = eppMod.EmpresaID;
            eppExist.PlatoID = eppMod.PlatoID;
            eppExist.ElementoID = eppMod.ElementoID;
            eppExist.Cantidad = eppMod.Cantidad;
            eppExist.Estado = eppMod.Estado;
            eppExist.FechaCreacion = eppMod.FechaCreacion;
            eppExist.FechaModificacion = eppMod.FechaModificacion;

            _contexto.Entry(eppExist).State = EntityState.Modified;
            _contexto.SaveChanges();

            return Ok(eppExist);

        }
    }
}
