using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PARCIAL2.Models;

namespace PARCIAL2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmpresaController : ControllerBase
    {

        private readonly ElementosporPlatoContext _contexto;
        public EmpresaController(ElementosporPlatoContext miContexto)
        {
            this._contexto = miContexto;
        }

        ///OBTERNER TODOS
        [HttpGet]
        [Route("api/ElementoPorPlato")]
        public IActionResult Get()
        {
            var EmpresaList = from em in _contexto.Empresas select em;

                              
            if (EmpresaList.Count() > 0)
            {
                return Ok(EmpresaList);
            }
            return NotFound();
        }

        ///OBTERNER ID
        [HttpGet]
        [Route("api/ElementoPorPlato/{ID}")]
        public IActionResult GetByID(char ID) {
            var Empresa = from ep in _contexto.Empresas
                          where ep.EmpresaID == ID
                          select ep;
            if(Empresa != null) {
                return Ok(Empresa);
            }
            return NotFound();
        }

        
        ///INGRESAR 
        [HttpPost]
        [Route("api/ElementoPorPlato")]
        public IActionResult guardarEmpresa([FromBody] Empresas EmpresaNuevo)
        {
            try
            {
                var EmpresaExist = from ep in _contexto.Empresas
                               where ep.EmpresaID == EmpresaNuevo.EmpresaID
                               select ep;


                if (EmpresaExist.Count() == 0)
                {
                    _contexto.Empresas.Add(EmpresaNuevo);
                    _contexto.SaveChanges();
                    return Ok(EmpresaNuevo);
                }
                return Ok(EmpresaExist);
            }
            catch (System.Exception)
            {
                return BadRequest();
            }
        }


        ///MODIFICAR
        [HttpPut]
        [Route("api/ElementoPorPlato")]
        public IActionResult updateElementoPorPlato([FromBody] Empresas EmpresaMod)
        {
            Empresas EmpresaExist = (from ep in _contexto.Empresas
                               where ep.EmpresaID == EmpresaMod.EmpresaID
                               select ep).FirstOrDefault();
            if (EmpresaExist is null)
            {
                return NotFound();
            }

            EmpresaExist.NombreEmpresa = EmpresaMod.NombreEmpresa;
            EmpresaExist.Representante = EmpresaMod.Representante;
            EmpresaExist.NIT = EmpresaMod.NIT;
            EmpresaExist.NRC = EmpresaMod.NRC;
            EmpresaExist.FechaCreacion = EmpresaMod.FechaCreacion;
            EmpresaExist.FechaModificacion = EmpresaMod.FechaModificacion;
            EmpresaExist.Direccion = EmpresaMod.Direccion;
            EmpresaExist.Correo = EmpresaMod.Correo;

            _contexto.Entry(EmpresaExist).State = EntityState.Modified;
            _contexto.SaveChanges();

            return Ok(EmpresaExist);

        }
    }
}