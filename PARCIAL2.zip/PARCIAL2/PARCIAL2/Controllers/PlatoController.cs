using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PARCIAL2.Models;

namespace PARCIAL2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PlatoController : ControllerBase
    {

        private readonly ElementosporPlatoContext _contexto;
        public PlatoController(ElementosporPlatoContext miContexto)
        {
            this._contexto = miContexto;
        }

        ///OBTERNER TODOS
        [HttpGet]
        [Route("api/Plato")]
        public IActionResult Get()
        {
            var PlatosList = from p in _contexto.Platos
                             join e in _contexto.Empresas on p.EmpresaID equals e.EmpresaID
                             select new {
                                p.PlatoID,
                                p.EmpresaID,
                                e.NombreEmpresa,
                                p.GrupoID,
                                p.NombrePlato,
                                p.DescripcionPlato,
                                p.Precio,
                                p.TiempoPreparacion,
                                p.Imagen,
                                p.AplicaPropina,
                                p.Lunes,
                                p.Martes,
                                p.Miercoles,
                                p.Jueves,
                                p.Viernes,
                                p.Sabado,
                                p.Domingo,
                                p.Estado,
                                p.FechaCreacion,
                                p.FechaModificacion
                             };

                              
            if (PlatosList.Count() > 0)
            {
                return Ok(PlatosList);
            }
            return NotFound();
        }

        ///OBTERNER ID
        [HttpGet]
        [Route("api/Plato/{ID}")]
        public IActionResult GetByID(char ID) {
            var plato = from p in _contexto.Platos
                        join e in _contexto.Empresas on p.EmpresaID equals e.EmpresaID
                        where p.PlatoID == ID
                        select new {
                           p.PlatoID,
                           p.EmpresaID,
                           e.NombreEmpresa,
                           p.GrupoID,
                           p.NombrePlato,
                           p.DescripcionPlato,
                           p.Precio,
                           p.TiempoPreparacion,
                           p.Imagen,
                           p.AplicaPropina,
                           p.Lunes,
                           p.Martes,
                           p.Miercoles,
                           p.Jueves,
                           p.Viernes,
                           p.Sabado,
                           p.Domingo,
                           p.Estado,
                           p.FechaCreacion,
                            p.FechaModificacion
                        };
            if(plato != null) {
                return Ok(plato);
            }
            return NotFound();
        }

        ///OBTERNER NOMBRE PLATO
        ///<param name="buscarnombre"></param>
        ///<returns></returns>
        [HttpGet]
        [Route("api/Plato/buscarnombre/{buscarnombre}")]
        public IActionResult GetByNombre(string buscarnombre) {
            var plato = from p in _contexto.Platos
                        join e in _contexto.Empresas on p.EmpresaID equals e.EmpresaID
                        where p.NombrePlato == buscarnombre
                        select new {
                           p.PlatoID,
                           p.EmpresaID,
                           e.NombreEmpresa,
                           p.GrupoID,
                           p.NombrePlato,
                           p.DescripcionPlato,
                           p.Precio,
                           p.TiempoPreparacion,
                           p.Imagen,
                           p.AplicaPropina,
                           p.Lunes,
                           p.Martes,
                           p.Miercoles,
                           p.Jueves,
                           p.Viernes,
                           p.Sabado,
                           p.Domingo,
                           p.Estado,
                           p.FechaCreacion,
                            p.FechaModificacion
                        };
            if(plato != null) {
                return Ok(plato);
            }
            return NotFound();
        }
        
        ///INGRESAR 
        [HttpPost]
        [Route("api/Plato")]
        public IActionResult guardarPlato([FromBody] Platos PlatoNuevo)
        {
            try
            {
                var PlatoExist = from p in _contexto.Platos
                                 join e in _contexto.Empresas on p.EmpresaID equals e.EmpresaID
                                 where p.PlatoID == PlatoNuevo.PlatoID
                                 select new {
                                    p.PlatoID,
                                    p.EmpresaID,
                                    e.NombreEmpresa,
                                    p.GrupoID,
                                    p.NombrePlato,
                                    p.DescripcionPlato,
                                    p.Precio,
                                    p.TiempoPreparacion,
                                    p.Imagen,
                                    p.AplicaPropina,
                                    p.Lunes,
                                    p.Martes,
                                    p.Miercoles,
                                    p.Jueves,
                                    p.Viernes,
                                    p.Sabado,
                                    p.Domingo,
                                    p.Estado,
                                    p.FechaCreacion,
                                     p.FechaModificacion
                                 };
                               
                if (PlatoExist.Count() == 0)
                {
                    _contexto.Platos.Add(PlatoNuevo);
                    _contexto.SaveChanges();
                    return Ok(PlatoNuevo);
                }
                return Ok(PlatoExist);
            }
            catch (System.Exception)
            {
                return BadRequest();
            }
        }


        ///MODIFICAR
        [HttpPut]
        [Route("api/Plato")]
        public IActionResult updatePlato([FromBody] Platos platoMod)
        {
            var PlatoExist = (from p in _contexto.Platos
                              join e in _contexto.Empresas on p.EmpresaID equals e.EmpresaID
                              where p.PlatoID == platoMod.PlatoID
                              select new {
                                 p.PlatoID,
                                 p.EmpresaID,
                                 e.NombreEmpresa,
                                 p.GrupoID,
                                 p.NombrePlato,
                                 p.DescripcionPlato,
                                 p.Precio,
                                 p.TiempoPreparacion,
                                 p.Imagen,
                                 p.AplicaPropina,
                                 p.Lunes,
                                 p.Martes,
                                 p.Miercoles,
                                 p.Jueves,
                                 p.Viernes,
                                 p.Sabado,
                                 p.Domingo,
                                 p.Estado,
                                 p.FechaCreacion,
                                  p.FechaModificacion
                              }).FirstOrDefault();
            if (PlatoExist is null)
            {
                return NotFound();
            }

            PlatoExist.PlatoID           = platoMod.PlatoID;
            PlatoExist.EmpresaID         = platoMod.EmpresaID;
            PlatoExist.GrupoID           = platoMod.GrupoID;
            PlatoExist.NombrePlato       = platoMod.NombrePlato;
            PlatoExist.DescripcionPlato  = platoMod.DescripcionPlato;
            PlatoExist.Precio            = platoMod.Precio;
            PlatoExist.TiempoPreparacion = platoMod.TiempoPreparacion;
            PlatoExist.Imagen            = platoMod.Imagen;
            PlatoExist.AplicaPropina     = platoMod.AplicaPropina;
            PlatoExist.Lunes             = platoMod.Lunes;
            PlatoExist.Martes            = platoMod.Martes;
            PlatoExist.Miercoles         = platoMod.Miercoles;
            PlatoExist.Jueves            = platoMod.Jueves;
            PlatoExist.Viernes           = platoMod.Viernes;
            PlatoExist.Sabado            = platoMod.Sabado;
            PlatoExist.Domingo           = platoMod.Domingo;
            PlatoExist.FechaCreacion     = platoMod.FechaCreacion;
            PlatoExist.FechaModificacion = platoMod.FechaModificacion;

            _contexto.Entry(PlatoExist).State = EntityState.Modified;
            _contexto.SaveChanges();

            return Ok(PlatoExist);
        }
    }
}