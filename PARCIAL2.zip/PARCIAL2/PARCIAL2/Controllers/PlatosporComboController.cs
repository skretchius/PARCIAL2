using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PARCIAL2.Models;

namespace PARCIAL2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PlatosporComboController : ControllerBase
    {

        private readonly ElementosporPlatoContext _contexto;
        public PlatosporComboController(ElementosporPlatoContext miContexto)
        {
            this._contexto = miContexto;
        }

        ///OBTERNER TODOS
        [HttpGet]
        [Route("api/ElementoPorPlato")]
        public IActionResult Get()
        {
            var pcList = from pc in _contexto.PlatosporCombos
                                  join em in _contexto.Empresas on pc.EmpresaID equals em.EmpresaID
                                  join pl in _contexto.Platos on pc.PlatoID equals pl.PlatoID
                                  select new {
                                     pc.PlatosPorComboID,
                                     pc.EmpresaID,
                                     em.NombreEmpresa,
                                     pc.ComboID,
                                     pc.PlatoID,
                                     pl.NombrePlato,
                                     pc.Estado,
                                     pc.FechaCreacion,
                                     pc.FechaModificacion
                                  };

                              
            if (pcList.Count() > 0)
            {
                return Ok(pcList);
            }
            return NotFound();
        }

        ///OBTERNER ID
        [HttpGet]
        [Route("api/ElementoPorPlato/{ID}")]
        public IActionResult GetByID(char ID) {
            var Platopc = from pc in _contexto.PlatosporCombos
                             join em in _contexto.Empresas on pc.EmpresaID equals em.EmpresaID
                             join pl in _contexto.Platos on pc.PlatoID equals pl.PlatoID
                             where pc.PlatosPorComboID == ID
                             select new
                             {
                                 pc.PlatosPorComboID,
                                 pc.EmpresaID,
                                 em.NombreEmpresa,
                                 pc.ComboID,
                                 pc.PlatoID,
                                 pl.NombrePlato,
                                 pc.Estado,
                                 pc.FechaCreacion,
                                 pc.FechaModificacion
                             };

            if (Platopc != null) {
                return Ok(Platopc);
            }
            return NotFound();
        }

        
        ///INGRESAR 
        [HttpPost]
        [Route("api/ElementoPorPlato")]
        public IActionResult guardarPlatoporCombo([FromBody] PlatosporCombo PCNuevo)
        {
            try
            {
                var PCEXist = from pc in _contexto.PlatosporCombos
                              join em in _contexto.Empresas on pc.EmpresaID equals em.EmpresaID
                              join pl in _contexto.Platos on pc.PlatoID equals pl.PlatoID
                              where pc.PlatosPorComboID == PCNuevo.PlatosPorComboID
                              select new
                              {
                                  pc.PlatosPorComboID,
                                  pc.EmpresaID,
                                  em.NombreEmpresa,
                                  pc.ComboID,
                                  pc.PlatoID,
                                  pl.NombrePlato,
                                  pc.Estado,
                                  pc.FechaCreacion,
                                  pc.FechaModificacion
                              };

                if (PCEXist.Count() == 0)
                {
                    _contexto.PlatosporCombos.Add(PCNuevo);
                    _contexto.SaveChanges();
                    return Ok(PCNuevo);
                }
                return Ok(PCEXist);
            }
            catch (System.Exception)
            {
                return BadRequest();
            }
        }


        ///MODIFICAR
        [HttpPut]
        [Route("api/ElementoPorPlato")]
        public IActionResult updatePlatoporCombo([FromBody] PlatosporCombo pcMod)
        {
            var pcExist = (from pc in _contexto.PlatosporCombos
                           join em in _contexto.Empresas on pc.EmpresaID equals em.EmpresaID
                           join pl in _contexto.Platos on pc.PlatoID equals pl.PlatoID
                           where pc.PlatosPorComboID == pcMod.PlatosPorComboID
                           select new
                           {
                               pc.PlatosPorComboID,
                               pc.EmpresaID,
                               em.NombreEmpresa,
                               pc.ComboID,
                               pc.PlatoID,
                               pl.NombrePlato,
                               pc.Estado,
                               pc.FechaCreacion,
                               pc.FechaModificacion
                           }).FirstOrDefault();
            if (pcExist is null)
            {
                return NotFound();
            }

            

            _contexto.Entry(pcMod).State = EntityState.Modified;
            _contexto.SaveChanges();

            return Ok(pcExist);

        }
    }
}