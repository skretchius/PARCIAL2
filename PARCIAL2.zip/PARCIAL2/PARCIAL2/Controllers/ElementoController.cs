using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PARCIAL2.Models;

namespace PARCIAL2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ElementosController : ControllerBase
    {

        private readonly ElementosporPlatoContext _contexto;
        public ElementosController(ElementosporPlatoContext miContexto)
        {
            this._contexto = miContexto;
        }

        ///OBTERNER TODOS
        [HttpGet]
        [Route("api/ElementoPorPlato")]
        public IActionResult Get()
        {
            var ElementosList = from el in _contexto.Elementos
                                  join em in _contexto.Empresas on el.EmpresaID equals em.EmpresaID
                                  select new {
                                     el.ElementoID,
                                     el.EmpresaID,
                                     em.NombreEmpresa,
                                     el.Elemento,
                                     el.CantidadMinima,
                                     el.UnidadMedida,
                                     el.Costo,
                                     el.Estado,
                                     el.FechaCreacion,
                                     el.FechaModificacion,
                                     el.inventario
                                  };

                              
            if (ElementosList.Count() > 0)
            {
                return Ok(ElementosList);
            }
            return NotFound();
        }

        ///OBTERNER ID
        [HttpGet]
        [Route("api/ElementoPorPlato/{ID}")]
        public IActionResult GetByID(char ID) {
            var Elemento = from el in _contexto.Elementos
                             join em in _contexto.Empresas on el.EmpresaID equals em.EmpresaID
                           where el.ElementoID == ID
                             select new
                             {
                                 el.ElementoID,
                                 el.EmpresaID,
                                 em.NombreEmpresa,
                                 el.Elemento,
                                 el.CantidadMinima,
                                 el.UnidadMedida,
                                 el.Costo,
                                 el.Estado,
                                 el.FechaCreacion,
                                 el.FechaModificacion,
                                 el.inventario
                             };
            if (Elemento != null) {
                return Ok(Elemento);
            }
            return NotFound();
        }

        
        ///INGRESAR 
        [HttpPost]
        [Route("api/ElementoPorPlato")]
        public IActionResult guardarElemento([FromBody] Elementos ElementoNuevo)
        {
            try
            {
                var ElementoExist = from el in _contexto.Elementos
                               join em in _contexto.Empresas on el.EmpresaID equals em.EmpresaID
                               where el.ElementoID == ElementoNuevo.ElementoID
                               select new
                               {
                                   el.ElementoID,
                                   el.EmpresaID,
                                   em.NombreEmpresa,
                                   el.Elemento,
                                   el.CantidadMinima,
                                   el.UnidadMedida,
                                   el.Costo,
                                   el.Estado,
                                   el.FechaCreacion,
                                   el.FechaModificacion,
                                   el.inventario
                               };

                if (ElementoExist.Count() == 0)
                {
                    _contexto.ElementosporPlatos.Add(ElementoNuevo);
                    _contexto.SaveChanges();
                    return Ok(ElementoNuevo);
                }
                return Ok(ElementoExist);
            }
            catch (System.Exception)
            {
                return BadRequest();
            }
        }


        ///MODIFICAR
        [HttpPut]
        [Route("api/ElementoPorPlato")]
        public IActionResult updateElemento([FromBody] Elementos elementoMod)
        {
            var elementoExist = (from el in _contexto.Elementos
                            join em in _contexto.Empresas on el.EmpresaID equals em.EmpresaID
                            where el.ElementoID == elementoMod.ElementoID
                            select new
                            {
                                el.ElementoID,
                                el.EmpresaID,
                                em.NombreEmpresa,
                                el.Elemento,
                                el.CantidadMinima,
                                el.UnidadMedida,
                                el.Costo,
                                el.Estado,
                                el.FechaCreacion,
                                el.FechaModificacion,
                                el.inventario
                            }).FirstOrDefault();
            if (elementoExist is null)
            {
                return NotFound();
            }



            _contexto.Entry(elementoMod).State = EntityState.Modified;
            _contexto.SaveChanges();

            return Ok(elementoExist);

        }
    }
}